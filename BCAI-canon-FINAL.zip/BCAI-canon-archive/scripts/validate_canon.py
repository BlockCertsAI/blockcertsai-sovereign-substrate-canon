import os, json, re

# ---------------------------
# Canon Structure Definition
# ---------------------------

REQUIRED_TOP_LEVEL = [
    "CANON_ROOT.md",
    "CANON_NAV.md",
    "CANON_MASTER_INDEX.md",
    "CANON_MASTER_INDEX.json",
    "CANON_LOADER.md",
    "CANON_VALIDATOR.md",
    "canon"
]

EXPECTED_LAYER_COUNT = 51

RETURN_PATH_BLOCK = [
    "Return to Navigation:",
    "[Root Specification]",
    "[Machine-Readable Master Index]",
    "[Human Navigation Map]"
]

# ---------------------------
# Helpers
# ---------------------------

def read_file(path):
    try:
        with open(path, "r") as f:
            return f.read()
    except:
        return ""

def fail(reason, report):
    report["status"] = "fail"
    report["errors"].append(reason)

# ---------------------------
# Validator
# ---------------------------

def validate():
    report = {
        "status": "pass",
        "errors": [],
        "missing_files": [],
        "bad_filenames": [],
        "missing_dependencies": [],
        "broken_links": [],
        "missing_return_paths": [],
        "integrity_score": 100
    }

    # ---------------------------
    # 1. Top-Level Validation
    # ---------------------------

    files = os.listdir(".")
    for req in REQUIRED_TOP_LEVEL:
        if req not in files and not os.path.isdir(req):
            report["missing_files"].append(req)

    if report["missing_files"]:
        fail("Missing required top-level files.", report)

    # ---------------------------
    # 2. Canon Layer Validation
    # ---------------------------

    if not os.path.isdir("canon"):
        fail("Missing canon directory.", report)
        return report

    canon_files = sorted(os.listdir("canon"))

    layer_files = [f for f in canon_files if f.endswith(".md")]
    if len(layer_files) != EXPECTED_LAYER_COUNT:
        fail(f"Expected {EXPECTED_LAYER_COUNT} layers, found {len(layer_files)}.", report)

    # Validate naming pattern: NN_Name_LN.md
    pattern = r"^(\d{2})_.+?_L\1\.md$"
    for f in layer_files:
        if not re.match(pattern, f):
            report["bad_filenames"].append(f)

    if report["bad_filenames"]:
        fail("Invalid layer filenames detected.", report)

    # ---------------------------
    # 3. Return Path Validation
    # ---------------------------

    for f in layer_files:
        content = read_file(os.path.join("canon", f))
        for required_line in RETURN_PATH_BLOCK:
            if required_line not in content:
                report["missing_return_paths"].append(f)
                fail(f"Missing return-path block in {f}", report)
                break

    # ---------------------------
    # 4. Integrity Score
    # ---------------------------

    penalty = (
        len(report["missing_files"]) * 5 +
        len(report["bad_filenames"]) * 3 +
        len(report["missing_return_paths"]) * 2
    )

    report["integrity_score"] = max(0, 100 - penalty)

    if report["status"] == "pass":
        report["integrity_score"] = 100

    return report

# ---------------------------
# Execute
# ---------------------------

if __name__ == "__main__":
    result = validate()
    print(json.dumps(result, indent=2))
