<!--
CANONICAL: TRUE
LAYER: MASTER_INDEX
AUTO-TOC: ENABLED
VERSION: 1.0
PURPOSE: Human-readable index for all Sovereign Substrate layers.
NOTES:
 - Do not remove this header.
 - This file mirrors the machine-readable JSON index.
-->

# Canon Master Index (Human Readable)

Below is the authoritative ordered list of all Sovereign Substrate layers.

1. L00_Overview  
2. L01_Identity  
3. L02_Vaults  
4. L03_MAIAi  
5. L04_Architect  
6. L05_Execution  
7. L06_ADT  
8. L07_CSR  
9. L08_Interoperability  
10. L09_Validation  
11. L10_Sealing  
12. L11_Proof_Primitives  
13. L12_Idempotence  
14. L13_Mutability  
15. L14_Temporal  
16. L15_Causality  
17. L16_Reversibility  
18. L17_Recovery  
19. L18_Provenance  
20. L19_Auditability  
21. L20_Attestation  
22. L21_Handoff  
23. L22_Permission  
24. L23_Capability  
25. L24_Boundary  
26. L25_Context_Propagation  
27. L26_Agent_Constraints  
28. L27_Validation_Rules  
29. L28_Execution_Envelope  
30. L29_Resource_Model  
31. L30_Authority  
32. L31_Trust  
33. L32_Secure_Channels  
34. L33_Data_Model  
35. L34_Governance  
36. L35_Policy  
37. L36_Identity_Fabric  
38. L37_Domain_Model  
39. L38_Consensus_Model  
40. L39_Workflows  
41. L40_State_Model  
42. L41_Security  
43. L42_Synchronization  
44. L43_Topology  
45. L44_Attestation_Flow  
46. L45_Delegation  
47. L46_Exception_Model  
48. L47_Interchange  
49. L48_Inference  
50. L49_Schema  
51. L50_Namespace

---

## Return to Navigation:
- [Root Specification](./CANON_ROOT.md)
- [Machine-Readable Master Index](./CANON_MASTER_INDEX.json)
- [Human Navigation Map](./CANON_NAV.md)
